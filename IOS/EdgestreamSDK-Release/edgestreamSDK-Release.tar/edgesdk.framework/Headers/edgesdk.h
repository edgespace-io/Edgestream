//
//  edgesdk.h
//  edgesdk
//
//  Created by George Vigelette on 12/9/18.
//  Copyright © 2018 George Vigelette. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for edgesdk.
FOUNDATION_EXPORT double edgesdkVersionNumber;

//! Project version string for edgesdk.
FOUNDATION_EXPORT const unsigned char edgesdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <edgesdk/PublicHeader.h>


